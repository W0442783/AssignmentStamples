public class Student {
    //attributes
    String studentName;
    double studentFirstGrade;
    double studentSecondGrade;

    //construct
    public Student(String pStudentName, double pStudentFirstGrade, double pStudentSecondGrade){
        this.studentName = pStudentName;
        this.studentFirstGrade = pStudentFirstGrade;
        this.studentSecondGrade = pStudentSecondGrade;
    }

}
