import java.util.Scanner;

public class Course {
    //attributes
    String course;

    //constructor
    public Course(String pClass) {
        this.course = pClass;
    }
}
