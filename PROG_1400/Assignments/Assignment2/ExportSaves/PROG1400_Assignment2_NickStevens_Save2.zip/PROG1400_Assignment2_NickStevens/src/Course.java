import java.util.Scanner;

public class Course {
    //attributes
    String course;


    //constructor
    public Course(String pCourse) {
        this.course = pCourse;
    }

    //Print name Method
    public String printCourse(Course currentCourse){
        return (currentCourse.course);
    }

}
