public class simpleArray {
}
