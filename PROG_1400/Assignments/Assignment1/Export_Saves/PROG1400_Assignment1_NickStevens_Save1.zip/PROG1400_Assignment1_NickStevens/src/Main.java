//Author:
//Date:
//Description:

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        //get the number of asterisks desired
        System.out.println("Enter number of asterisks: ");

        //first arrayLength variable will be used for the first half
        int arrayLength =  sc.nextInt();

        //second array length variable will be used for the second half
        int arrayLengthLoopTwo = arrayLength;

        //set the array length to the value entered (desired number of asterisks)
        String[] asteriskArray = new String[arrayLength];


        //first loop controls the number of lines printed
        for (int i = 0; i < arrayLength;) {
            //first nested loop fills the array with the desired number of asterisks
            for (int j = 0; j < arrayLength; j++) {
                asteriskArray[j] = "*";
            }

            //print the current array
            System.out.println(Arrays.toString(asteriskArray));

            //second nested loop replaces the furthest asterisk element in the array with a blank character
            for (int k = 0; k < arrayLength; k++) {
                asteriskArray[k] = "";
            }

            //decrement the array length to control the number of lines printed
            //and control which asterisk element gets replaced with a blank character
            //in the next round of the second nested loop
            arrayLength--;
        }

        //refill the aray with asterisks
        for (int j = 0; j < arrayLengthLoopTwo; j++){
            asteriskArray[j] = "*";
        }

        //set a counter to be used to control which asterisk element gets replaced with
        //a blank character
        int counter = 0;

        //first loop controls number of lines printed
        for (int i = 0; i < arrayLengthLoopTwo;){

            //print the array
            System.out.println(Arrays.toString(asteriskArray));

            //nested loop to replace the earliest asterisk element with a blank line
            for (int k = 0; k < arrayLengthLoopTwo; k++) {
                asteriskArray[counter] = " ";
            }

            //increment the counter to control which asterisk element gets replaced by a blank line
            //in the next round of the nested loop
            counter++;

            //decrement the array length to control the number of lines printed
            arrayLengthLoopTwo--;
        }


    }
}