//Author:
//Date:
//Description:

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //------------------------------Part 1------------------------------//

        //banner
        System.out.println("Welcome to Part 1!");

        //get the number of asterisks desired
        System.out.println("Enter number of asterisks: ");

        //first arrayLength variable will be used for the first half
        int arrayLength = sc.nextInt();

        //second array length variable will be used for the second half
        int arrayLengthLoopTwo = arrayLength;

        //set the array length to the value entered (desired number of asterisks)
        String[] asteriskArray = new String[arrayLength];


        //first loop controls the number of lines printed
        for (int i = 0; i < arrayLength; ) {
            //first nested loop fills the array with the desired number of asterisks
            for (int j = 0; j < arrayLength; j++) {
                asteriskArray[j] = "*";
            }

            //print the current array
            System.out.println(Arrays.toString(asteriskArray));

            //second nested loop replaces the furthest asterisk element in the array with a blank line
            for (int k = 0; k < arrayLength; k++) {
                asteriskArray[k] = " ";
            }

            //decrement the array length to control the number of lines printed
            //and control which asterisk element gets replaced with a blank character
            //in the next round of the second nested loop
            arrayLength--;
        }

        //refill the aray with asterisks
        for (int j = 0; j < arrayLengthLoopTwo; j++) {
            asteriskArray[j] = "*";
        }

        //set a counter to be used to control which asterisk element gets replaced with
        //a blank character
        int counter = 0;

        //first loop controls number of lines printed
        for (int i = 0; i < arrayLengthLoopTwo; ) {

            //print the array
            System.out.println(Arrays.toString(asteriskArray));

            //nested loop to replace the earliest asterisk element with a blank line
            for (int k = 0; k < arrayLengthLoopTwo; k++) {
                asteriskArray[counter] = " ";
            }

            //increment the counter to control which asterisk element gets replaced by a blank line
            //in the next round of the nested loop
            counter++;

            //decrement the array length to control the number of lines printed
            arrayLengthLoopTwo--;
        }


        //------------------------------Part 2------------------------------//

        //banner
        System.out.println();
        System.out.println("Welcome to Part 2!");

        int[] studentMarks = new int[10];

        //counter to print which element is being input
        counter = 0;

        for (int i = 0; i < studentMarks.length; i++) {
            counter++;
            System.out.println("Enter mark #" + counter + ":");
            studentMarks[i] = sc.nextInt();
        }

        //seed values for highest/lowest mark
        int lowestMark = studentMarks[0];
        int highestMark = studentMarks[0];

        //declaration and initialization of average mark variables
        int addAverageMark = 0;
        int averageMark = 0;

        //loop for finding min, max, and average mark
        for (int i = 0; i < studentMarks.length; i++) {

            //find the highest and lowest mark
            if (studentMarks[i] < lowestMark) {
                lowestMark = studentMarks[i];
            }
            if (studentMarks[i] > highestMark) {
                highestMark = studentMarks[i];
            }

            //add up the average
            addAverageMark += studentMarks[i];

            //divide added up marks by number of marks (length of array)
            //in order to find the average mark
            averageMark = addAverageMark / studentMarks.length;
        }

        //print the min, max, and average mark
        System.out.println();
        System.out.println("Final Report");
        System.out.println("Total marks: " + addAverageMark);
        System.out.println("Mark average: " + averageMark);
        System.out.println("Maximum mark: " + highestMark);
        System.out.println("Minimum mark: " + lowestMark);

        //------------------------------Part 3------------------------------//

        //banner
        System.out.println();
        System.out.println("Welcome to Part 3!");

        //hard code rows and column length as variables in order to more easily iterate
        //through nested loops later
        int rows = 3;
        int cols = 4;

        //counter used to fill matrix with data
        int inputData = 0;

        //create 2D array with hard coded rows and columns taken from instruction example
        int matrix [][] = new int[rows][cols];

        //create simple array with 12 element spaces to fit the 2D matrix array elements
        int[] simpleArray = new int[12];

        //fill 2D array with values
        for (int i = 0; i < rows; i++){
            for (int j = 0; j < cols; j++){
                inputData += 5;
                matrix[i][j] = inputData;
            }
        }

        //space added for sake of formatting
        System.out.print(" ");

        //print 2D array values
        for (int i = 0; i < rows; i++){
            for (int j = 0; j < cols; j++){
                System.out.print(matrix[i][j] + " ");
            }

            //print new line character after each row
            System.out.print("\n");
        }

        //counter to track which simple array element is being written to
        counter = 0;

        //nested loop which iterates though the rows and columns of the 2D array and assigns each value
        //to consecutive simple array
        for(int j = 0; j < cols; j++) {
            for (int i = 0; i < rows; i++) {
                simpleArray[counter] = matrix[i][j];
                counter++;
            }
        }

        //pint simple array
        System.out.println();
        System.out.println("Converted array elements are:");
        for (int i = 0; i < simpleArray.length; i++){
            System.out.println(simpleArray[i]);
        }
    }

}