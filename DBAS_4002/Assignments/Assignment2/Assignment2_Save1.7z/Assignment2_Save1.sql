--1.	A new table called RecordLogging will be added. See ERD below.
USE Chinook
CREATE TABLE RecordLogging (
	LogID int identity(1,1),
	TableName VARCHAR(30),
	RecordID int,
	ActionType VARCHAR(30) NOT NULL,
	IsError bit NOT NULL,
	ErrorNum int, 
	LogDate DATETIME NOT NULL,
	PRIMARY KEY(LogID)
);

--DROP TABLE RecordLogging;

--INSERT INTO RecordLogging(TableName, RecordID, ActionType, IsError, ErrorNum, LogDate)
--VALUES ('testname', 1, 'INSERT', 0, 0, '03/07/2023');

--DELETE FROM RecordLogging
--WHERE RecordLogging.TableName = 'testname';

--2.	A new stored procedure called uspAddRecordLog 
GO
CREATE PROC uspAddRecordLog 
	@tableName VARCHAR(30),
	@actionType CHAR(6),
	@isError bit,
	@recordID int = -1,
	@errorNum int = 0
AS 
	INSERT INTO RecordLogging(TableName, RecordID, ActionType, IsError, ErrorNum, LogDate)
	VALUES (@tableName, @recordID, @actionType, @isError, @errorNum, GETDATE())
;


--TRUNCATE TABLE RecordLogging;

--EXEC uspAddRecordLog @tableName = 'Track', @actionType = 'Insert', @isError = 0;
	


--3.	For each of the five tables (Tracks, Artists, Albums, Genres and Mediatypes), add a new stored procedure called usp<TableName>_Insert.
GO
CREATE PROC uspTracks_Insert(
	@name VARCHAR(200),
	@mediaType int,
	@milliseonds int,
	@unitPrice numeric(10,2),
	@albumID int = NULL,
	@genreID int = NULL,
	@composer VARCHAR(220) = NULL,
	@bytes int = NULL
)
AS
	BEGIN TRANSACTION
		BEGIN TRY
				INSERT INTO Track(Name, MediaTypeId, Milliseconds, UnitPrice, AlbumId, GenreId, Composer, Bytes)
				VALUES (@name, @mediaType, @milliseonds, @unitPrice, @albumID, @genreID, @composer, @bytes)


				DECLARE @trkRecordID_suc int = SCOPE_IDENTITY()
				EXEC uspAddRecordLog @tableName = 'Track', @actionType = 'INSERT', @isError = 0, @recordID = @trkRecordID_suc
		END TRY

		BEGIN CATCH
			DECLARE @trkErrorNum int = ERROR_NUMBER()
			DECLARE @trkRecordID_err int = SCOPE_IDENTITY()

			EXEC uspAddRecordLog @tableName = 'Track', @actionType = 'INSERT', @isError = 1, @recordID = @trkRecordID_err, @errorNum = @trkErrorNum

			IF @@TRANCOUNT > 0
					ROLLBACK
		END CATCH

	IF @@TRANCOUNT > 0
		COMMIT

;

--EXEC uspTracks_Insert @name = 'testSongSuc' , @mediaType = 1, @milliseonds = 343719, @unitPrice = 0.99;
--EXEC uspTracks_Insert @name = 'testSongErr' , @mediaType = 'one', @milliseonds = 343719, @unitPrice = 0.99, @albumID = 99, @genreID = 1, @composer = 'Talented Guy', @bytes = 109385;

SELECT *

FROM Track

WHERE Name = 'testSong'
;
	

--4. 4.	For each of the five tables (Tracks, Artists, Albums, Genres and Mediatypes), add a new stored procedure called usp<TableName>_DeleteByID